Put these two folders (".github" and "tools") into the root of your PRIVATE scores repository (PianistScores).
GitHub web page of that repository -> "Add file" -> "Upload files" -> drag the two folders in -> "Commit changes".
After that, PDF conversion no longer needs the code repository at all.
(lab.yml: a private comparison of the recognition engines on your own PDFs; put them in a folder "lab" of that repository; they are deleted after the run and after two days at the latest.)
